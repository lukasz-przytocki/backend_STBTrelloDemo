package organizations;

import base.BaseTest;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;

public class OrganizationsTest extends BaseTest {

    @Test
    public void createNewOrganization(){
        Response response = given()
                .spec(reqSpec)
                .queryParam("displayName","Test_oraganization")
                .queryParam("desc", "Organization for test purpose")
                .queryParam("name","abc")
                .queryParam("website", "https://github.com/")
                .when()
                .post(BASIC_URL+"/"+ORGANIZATIONS)
                .then()
                .statusCode(200)
                .extract()
                .response();

        JsonPath jsonPath = response.jsonPath();
        Assertions.assertThat(jsonPath.getString("displayName").contains("Test_oraganization"));
        Assertions.assertThat(jsonPath.getString("desc").contains("Organization for test purpose"));
        Assertions.assertThat(jsonPath.getString("name").contains("abc"));
        Assertions.assertThat(jsonPath.getString("website").contains("https://github.com/"));

    }
}
